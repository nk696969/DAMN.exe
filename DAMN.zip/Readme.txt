-DAMN.exe-
its joke prank virus but we are not responsible for any damage caused by this software
its all your self responsibility

if you want quit this virus, click "want to quit this? click here" link or
do taskkill (use taskmgr or cmd)

coded by nk
coded lang C#